
# SpamDetector



This Django project provides a REST API to allow users to register, log in, and mark phone numbers as spam. This backend service is designed to support a mobile app for identifying spam callers.

## Features

- Spam Detection by Phone Number or Name: Users can search by phone number or name to check if a contact is marked as spam.

- Database Lookup: Leverages a backend database of known spam contacts for fast and accurate responses.

- REST API: Provides API endpoints for external systems to check spam status by phone number or name.
## Tech Stack

**Django** : Backend framework to handle queries and manage the web application.

**SQLite**: Database to store and manage contact records.


## Installation

**Prerequisites:**
 - Python 3.8+
 - Django 4.0+
 - Virtualenv (optional but recommended)


**Installation Steps:**

1. Extract the file.

2. create and activate the virtual enviornment
```bash
  python3 -m venv env
  env\Scripts\activate    #for winwdows
```
3. Install dependencies
```bash
   pip install -r requirements.txt
``` 
4. Run database Migrations
```bash
   python manage.py makemigrations
   python manage.py migrate
``` 
5. Populate the data for testing(optional)
```bash 
   python manage.py populate_data
```

5. Start the development server:
```bash
   python manage.py runserver
``` 
6. access the app: open the browser and go to http://127.0.0.1:8000
## API Endpoints

To Register a User 
```bash
http://127.0.0.1:8000/api/users/register/
```
To mark any contact as spam
```bash
http://127.0.0.1:8000/api/users/spam/mark/
```

To search any contact by phone bumber
```bash
http://127.0.0.1:8000/api/users/search/phone/<str:query>/

```

To search any contact by name
```bash
http://127.0.0.1:8000/api/users/search/name/<str:query>/

```




## Screenshots

![App Screenshot](https://via.placeholder.com/468x300?text=App+Screenshot+Here)


