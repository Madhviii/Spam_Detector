from django.core.management.base import BaseCommand
from faker import Faker
from users.models import User, Contact, Spam
import random

fake = Faker()

class Command(BaseCommand):
    help = 'Populate the database with random data'

    def handle(self, *args, **kwargs):
        self.populate_users()
        self.populate_contacts()
        self.populate_spam()

    def populate_users(self):
        print("Creating Users...")
        for _ in range(50):
            User.objects.create(
                name=fake.name(),
                phone_number=fake.phone_number(),
                email=fake.email(),
                password=fake.password()
            )
        print("Users created successfully.")

    def populate_contacts(self):
        print("Creating Contacts...")
        users = list(User.objects.all())
        for _ in range(200):
            user = random.choice(users)
            Contact.objects.create(
                user=user,
                contact_name=fake.name(),
                phone_number=fake.phone_number()
            )
        print("Contacts created successfully.")

    def populate_spam(self):
        print("Creating Spam Entries...")
        for _ in range(30):
            Spam.objects.create(
                phone_number=fake.phone_number(),
                is_spam=True
            )
        print("Spam entries created successfully.")
