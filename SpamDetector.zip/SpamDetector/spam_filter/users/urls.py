from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_user, name='register_user'),
    path('getallcontacts/', views.getallcontacts, name='getallcontacts'),
    path('getall/', views.getall, name='getall'),
    path('getallspams/', views.getallspams, name='getallspams'),
    path('search/name/<str:query>/', views.search_by_name, name='search_by_name'),
    path('search/phone/<str:query>/', views.search_by_phone, name='search_by_phone'),
    path('spam/mark/', views.mark_spam, name='mark_spam'),
]
