from rest_framework import status
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.contrib.auth.hashers import make_password
from .models import User, Contact, Spam
from .serializers import UserSerializer, ContactSerializer, SpamSerializer

# Registration view for new users
@api_view(['POST'])
def register_user(request):
    data = request.data
    password = make_password(data['password'])  # Secure the password
    data['password'] = password
    serializer = UserSerializer(data=data)

    if serializer.is_valid():
        user = serializer.save()
        return Response({
            "message": "User registered successfully",
            "user": serializer.data,
            "contacts_added": [contact.contact_name for contact in user.contacts.all()]
        }, status=status.HTTP_201_CREATED)
    
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Search for contacts by name
@api_view(['GET'])
def search_by_name(request, query):
    contacts = Contact.objects.filter(contact_name__icontains=query)
    results = [
        {
            'contact_name': contact.contact_name,
            'phone_number': contact.phone_number,
            'is_spam': Spam.objects.filter(phone_number=contact.phone_number).exists()
        }
        for contact in contacts
    ]
    return Response(results)

@api_view(['GET'])
def getall(request):
    users = User.objects.all()  # Queryset of all users
    serializer = UserSerializer(users, many=True)  # Serialize the queryset
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getallcontacts(request):
    users = Contact.objects.all()  # Queryset of all users
    serializer = ContactSerializer(users, many=True)  # Serialize the queryset
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['GET'])
def getallspams(request):
    spams = Spam.objects.all()
    serializer = SpamSerializer(spams, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

from django.shortcuts import get_object_or_404

@api_view(['GET'])
def search_by_phone(request, query):
    # requester_phone = request.GET.get('requester_phone', None)    
    # if not requester_phone:
    # #     return Response({"error": "Requester phone number is required"}, status=status.HTTP_400_BAD_REQUEST)
    # # requester = User.objects.filter(phone_number=requester_phone).first()
    # # if not requester:
    # #     return Response({"error": "Requester is not a registered user"}, status=status.HTTP_404_NOT_FOUND)
    users = User.objects.filter(phone_number=query)
    results = []
    for user in users:
        # is_in_contact_list = Contact.objects.filter(
        #     user=user, phone_number=requester_phone
        # ).exists()
        user_data = {
            'name': user.name,
            'phone_number': user.phone_number,
            'is_spam': Spam.objects.filter(phone_number=user.phone_number).exists(),
        }
        # if is_in_contact_list:
        #     user_data['email'] = user.email
        results.append(user_data)
    contacts = Contact.objects.filter(phone_number=query)
    for contact in contacts:
        contact_data = {
            'contact_name': contact.contact_name,
            'phone_number': contact.phone_number,
            'is_spam': Spam.objects.filter(phone_number=contact.phone_number).exists(),
        }
        results.append(contact_data)
    return Response(results, status=status.HTTP_200_OK)

# Mark a phone number as spam
@api_view(['POST'])
def mark_spam(request):
    phone_number = request.data.get('phone_number')
    if phone_number:
        spam, created = Spam.objects.get_or_create(phone_number=phone_number)
        spam.is_spam = True
        spam.save()
        return Response({"message": "Spam marked successfully"}, status=status.HTTP_200_OK)
    return Response({"error": "Phone number required"}, status=status.HTTP_400_BAD_REQUEST)

class MarkSpamView(APIView):
    def post(self, request):
        serializer = SpamSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
