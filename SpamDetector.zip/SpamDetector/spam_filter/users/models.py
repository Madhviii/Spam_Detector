from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

# User model to store information about each user
class User(models.Model):
    name = models.CharField(max_length=100)
    phone_number = models.CharField(unique=True, max_length=15)
    email = models.EmailField(null=True, blank=True)
    password = models.CharField(max_length=128)

    def __str__(self):
        return self.name

# Contact model to store each user's contacts
class Contact(models.Model):
    user = models.ForeignKey(User, related_name='contacts', on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    contact_name = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.contact_name} ({self.phone_number})'

# Spam model to store the spam numbers
class Spam(models.Model):
    phone_number = models.CharField(max_length=15, unique=True)
    is_spam = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.phone_number} - {'Spam' if self.is_spam else 'Not Spam'}"

# Signal to create dummy contacts after a user is registered
@receiver(post_save, sender=User)
def create_dummy_contacts(sender, instance, created, **kwargs):
    if created:
        # Define some dummy contacts
        dummy_contacts = [
            {"contact_name": "Alice", "phone_number": "1234567890"},
            {"contact_name": "Bob", "phone_number": "0987654321"},
            {"contact_name": "Charlie", "phone_number": "1122334455"},
            {"contact_name": "Dave", "phone_number": "12345"},
        ]
        
        # Create dummy contacts for the registered user
        for contact in dummy_contacts:
            Contact.objects.create(
                user=instance,
                contact_name=contact["contact_name"],
                phone_number=contact["phone_number"]
            )
